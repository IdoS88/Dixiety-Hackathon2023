# Tinder swipe cards

A Pen created on CodePen.io. Original URL: [https://codepen.io/RobVermeer/pen/japZpY](https://codepen.io/RobVermeer/pen/japZpY).

Tinder swipe cards made with hammer.js.